class PagesController < ApplicationController
  def home
  end

  def about
  end

  def consulting
  end

  def careers
  end

  def contact
  end

  def impressum
  end

  def test
  end
end
